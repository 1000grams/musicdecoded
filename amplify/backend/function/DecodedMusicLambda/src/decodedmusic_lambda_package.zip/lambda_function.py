import json
import boto3
import uuid

dynamodb = boto3.client('dynamodb')
table_name = 'DecodedCTA'

def lambda_handler(event, context):
    method = event['httpMethod']

    if method == 'GET':
        response = dynamodb.scan(TableName=table_name)
        items = [
            {'id': item['id']['S'], 'title': item['title']['S'], 'link': item['link']['S']}
            for item in response.get('Items', [])
        ]
        return {
            'statusCode': 200,
            'headers': {'Content-Type': 'application/json'},
            'body': json.dumps(items)
        }

    elif method == 'POST':
        body = json.loads(event['body'])
        dynamodb.put_item(
            TableName=table_name,
            Item={
                'id': {'S': str(uuid.uuid4())},
                'title': {'S': body['title']},
                'link': {'S': body['link']}
            }
        )
        return {
            'statusCode': 201,
            'headers': {'Content-Type': 'application/json'},
            'body': json.dumps({'message': 'CTA created'})
        }

    return {
        'statusCode': 405,
        'body': json.dumps({'message': 'Method Not Allowed'})
    }